#ifndef _SCHED_H_
#define _SCHED_H_

void handle_irq();
void sched_yield();

#endif