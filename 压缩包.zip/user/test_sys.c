#include "lib.h"

void umain()
{
    writef("alouha.\n");
}
